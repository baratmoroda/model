﻿#include <iostream>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <random>
#include <cmath>
#include <fstream>
#include <string>

using namespace std;

class Module {
public:
    int id;
    double load; 
    vector<int> next; 
    vector<int> prev; 

    Module(int id = 0, double load = 0.0) : id(id), load(load) {}
};

class Agent {
public:
    int id;
    double speed; 
    vector<int> neighbors;
    vector<int> assignedModules;
    double currentLoad; 
    bool isFailed;

    Agent(int id = 0, double speed = 1.0) : id(id), speed(speed),
        currentLoad(0.0), isFailed(false) {}
};


class WorkloadModel {
public:
    vector<Module> modules;
    set<int> startModules; 
    set<int> endModules; 


    void addModule(int id, double load) {
        modules.emplace_back(id, load);
    }


    void addDependency(int from, int to) {
        if (from < (int)modules.size() && to < (int)modules.size()) {
            modules[from].next.push_back(to);
            modules[to].prev.push_back(from);
        }
    }


    void identifyStartEndModules() {
        startModules.clear();
        endModules.clear();

        for (const auto& module : modules) {
            if (module.prev.empty()) {
                startModules.insert(module.id);
            }
            if (module.next.empty()) {
                endModules.insert(module.id);
            }
        }
    }


    Module& getModule(int id) {
        return modules[id];
    }


    void print() const {
        cout << "=== Граф нагрузки ===" << endl;
        cout << "Модули: " << modules.size() << endl;
        for (const auto& module : modules) {
            cout << "Модуль " << module.id << ": нагрузка=" << module.load;
            cout << ", след. модули: ";
            for (int n : module.next) cout << n << " ";
            cout << endl;
        }
        cout << "Начальные модули: ";
        for (int s : startModules) cout << s << " ";
        cout << endl;
        cout << "Конечные модули: ";
        for (int e : endModules) cout << e << " ";
        cout << endl;
    }
};


class MASModel {
public:
    vector<Agent> agents;


    void addAgent(int id, double speed = 1.0) {
        agents.emplace_back(id, speed);
    }


    void addConnection(int agent1, int agent2) {
        if (agent1 < (int)agents.size() && agent2 < (int)agents.size()) {
            agents[agent1].neighbors.push_back(agent2);
            agents[agent2].neighbors.push_back(agent1);
        }
    }


    Agent& getAgent(int id) {
        return agents[id];
    }


    void print() const {
        cout << "=== Граф МАС ===" << endl;
        cout << "Агенты: " << agents.size() << endl;
        for (const auto& agent : agents) {
            cout << "Агент " << agent.id << ": скорость=" << agent.speed;
            cout << ", соседи: ";
            for (int n : agent.neighbors) cout << n << " ";
            cout << endl;
        }
    }
};


class LoadBalancer {
private:
    WorkloadModel& workload;
    MASModel& mas;
    mt19937 rng;
    uniform_real_distribution<double> probDist;


    map<int, int> moduleToAgent;
    queue<int> readyModules;
    map<int, double> finishTimes;
    map<int, double> startTimes;
    map<int, int> moduleStatus;
    vector<double> agentAvailableTime;

public:
    LoadBalancer(WorkloadModel& wl, MASModel& masModel)
        : workload(wl), mas(masModel), rng(random_device{}()),
        probDist(0.0, 1.0) {
        agentAvailableTime.resize(mas.agents.size(), 0.0);
    }

    void initialDistribution() {
        moduleToAgent.clear();

        vector<pair<double, int>> modulesByLoad;
        for (const auto& module : workload.modules) {
            modulesByLoad.emplace_back(module.load, module.id);
        }
        sort(modulesByLoad.begin(), modulesByLoad.end(),
            greater<pair<double, int>>());

        for (size_t i = 0; i < modulesByLoad.size(); i++) {
            double load = modulesByLoad[i].first;
            int moduleId = modulesByLoad[i].second;

            int bestAgent = 0;
            double minLoad = mas.agents[0].currentLoad;

            for (size_t j = 1; j < mas.agents.size(); j++) {
                if (mas.agents[j].currentLoad < minLoad) {
                    minLoad = mas.agents[j].currentLoad;
                    bestAgent = (int)j;
                }
            }

            assignModuleToAgent(moduleId, bestAgent);
        }

        initializeReadyQueue();
    }

    void assignModuleToAgent(int moduleId, int agentId) {
        moduleToAgent[moduleId] = agentId;
        mas.agents[agentId].assignedModules.push_back(moduleId);
        mas.agents[agentId].currentLoad += workload.getModule(moduleId).load;
        moduleStatus[moduleId] = 0; 
    }

    void initializeReadyQueue() {
        for (int moduleId : workload.startModules) {
            readyModules.push(moduleId);
        }
    }

    bool isModuleReady(int moduleId) {
        const Module& module = workload.getModule(moduleId);

        for (int prevId : module.prev) {
            if (moduleStatus[prevId] != 2) { 
                return false;
            }
        }
        return true;
    }

    double simulateExecution(bool enableRedistribution = true) {
        double currentTime = 0.0;
        int completedModules = 0;
        int totalModules = (int)workload.modules.size();

        auto completeModule = [&](int moduleId) {
            moduleStatus[moduleId] = 2;
            completedModules++;

            for (int nextId : workload.getModule(moduleId).next) {
                if (isModuleReady(nextId)) {
                    readyModules.push(nextId);
                }
            }
            };

        while (completedModules < totalModules) {
            vector<int> modulesToProcess;
            while (!readyModules.empty()) {
                int moduleId = readyModules.front();
                readyModules.pop();
                modulesToProcess.push_back(moduleId);
            }

            for (int moduleId : modulesToProcess) {
                if (moduleStatus[moduleId] == 0) { 
                    int agentId = moduleToAgent[moduleId];

                    if (enableRedistribution && probDist(rng) < 0.05) {
                        cout << "Время " << currentTime << ": ОТКАЗ агента "
                            << agentId << " при выполнении модуля " << moduleId << endl;

                        dynamicRedistribution(moduleId);
                        agentId = moduleToAgent[moduleId]; 
                    }

                    if (!mas.agents[agentId].isFailed) {
                        double startTime = max(currentTime, agentAvailableTime[agentId]);
                        double executionTime = workload.getModule(moduleId).load /
                            mas.agents[agentId].speed;
                        double finishTime = startTime + executionTime;

                        startTimes[moduleId] = startTime;
                        finishTimes[moduleId] = finishTime;
                        agentAvailableTime[agentId] = finishTime;
                        moduleStatus[moduleId] = 1; 

                        cout << "Время " << startTime << ": Модуль " << moduleId
                            << " начал выполняться на агенте " << agentId
                            << ", завершится в " << finishTime << endl;
                    }
                }
            }

            double nextCompletionTime = 1e9;
            int nextModuleToComplete = -1;

            for (map<int, int>::const_iterator it = moduleStatus.begin();
                it != moduleStatus.end(); ++it) {
                int moduleId = it->first;
                int status = it->second;

                if (status == 1) { 
                    if (finishTimes[moduleId] < nextCompletionTime) {
                        nextCompletionTime = finishTimes[moduleId];
                        nextModuleToComplete = moduleId;
                    }
                }
            }

            if (nextModuleToComplete != -1) {
                currentTime = nextCompletionTime;
                completeModule(nextModuleToComplete);

                cout << "Время " << currentTime << ": Модуль "
                    << nextModuleToComplete << " завершён" << endl;
            }
        }

        double totalTime = 0.0;
        for (int endModule : workload.endModules) {
            totalTime = max(totalTime, finishTimes[endModule]);
        }

        return totalTime;
    }

    void dynamicRedistribution(int failedModuleId) {
        int failedAgentId = moduleToAgent[failedModuleId];
        mas.agents[failedAgentId].isFailed = true;

        int newAgentId = -1;
        for (int neighborId : mas.agents[failedAgentId].neighbors) {
            if (!mas.agents[neighborId].isFailed) {
                newAgentId = neighborId;
                break;
            }
        }

        if (newAgentId == -1) {
            for (size_t i = 0; i < mas.agents.size(); i++) {
                if (!mas.agents[i].isFailed) {
                    newAgentId = (int)i;
                    break;
                }
            }
        }

        if (newAgentId != -1) {
            auto& oldAgent = mas.agents[failedAgentId];
            auto it = find(oldAgent.assignedModules.begin(),
                oldAgent.assignedModules.end(), failedModuleId);
            if (it != oldAgent.assignedModules.end()) {
                oldAgent.assignedModules.erase(it);
            }

            assignModuleToAgent(failedModuleId, newAgentId);

            cout << "Модуль " << failedModuleId << " перенесён с агента "
                << failedAgentId << " на агент " << newAgentId << endl;
        }
    }

    void printDistribution() const {
        cout << "=== Распределение нагрузки ===" << endl;
        for (const auto& agent : mas.agents) {
            cout << "Агент " << agent.id << " (нагрузка=" << agent.currentLoad
                << "): модули ";
            for (int moduleId : agent.assignedModules) {
                cout << moduleId << "(" << workload.getModule(moduleId).load << ") ";
            }
            cout << endl;
        }
    }
};

void testCase1() {
    cout << "\n=========== ТЕСТ 1: Простая цепочка ===========" << endl;

    WorkloadModel workload;
    MASModel mas;

    for (int i = 0; i < 3; i++) {
        workload.addModule(i, 10.0); 
    }
    workload.addDependency(0, 1);
    workload.addDependency(1, 2);
    workload.identifyStartEndModules();

    mas.addAgent(0, 1.0);
    mas.addAgent(1, 1.0);
    mas.addConnection(0, 1);

    LoadBalancer balancer(workload, mas);
    workload.print();
    mas.print();

    balancer.initialDistribution();
    balancer.printDistribution();

    double totalTime = balancer.simulateExecution(true);
    cout << "Общее время выполнения: " << totalTime << endl;
}

void testCase2() {
    cout << "\n=========== ТЕСТ 2: Параллельные ветви ===========" << endl;

    WorkloadModel workload;
    MASModel mas;

    for (int i = 0; i < 5; i++) {
        workload.addModule(i, 5.0 + i); 
    }
    workload.addDependency(0, 1);
    workload.addDependency(0, 2);
    workload.addDependency(1, 3);
    workload.addDependency(2, 3);
    workload.addDependency(3, 4);
    workload.identifyStartEndModules();

    mas.addAgent(0, 1.0);
    mas.addAgent(1, 1.5); 
    mas.addAgent(2, 0.8); 
    mas.addConnection(0, 1);
    mas.addConnection(1, 2);
    mas.addConnection(0, 2);

    LoadBalancer balancer(workload, mas);
    workload.print();
    mas.print();

    balancer.initialDistribution();
    balancer.printDistribution();

    double totalTime = balancer.simulateExecution(true);
    cout << "Общее время выполнения: " << totalTime << endl;
}

void testCase3() {
    cout << "\n=========== ТЕСТ 3: Сложный граф ===========" << endl;

    WorkloadModel workload;
    MASModel mas;

    for (int i = 0; i < 7; i++) {
        workload.addModule(i, 2.0 * (i + 1));
    }
    workload.addDependency(0, 1);
    workload.addDependency(0, 2);
    workload.addDependency(1, 3);
    workload.addDependency(1, 4);
    workload.addDependency(2, 4);
    workload.addDependency(3, 5);
    workload.addDependency(4, 5);
    workload.addDependency(5, 6);
    workload.identifyStartEndModules();

    for (int i = 0; i < 4; i++) {
        mas.addAgent(i, 0.5 + i * 0.3);
    }
    for (int i = 0; i < 4; i++) {
        mas.addConnection(i, (i + 1) % 4);
    }

    LoadBalancer balancer(workload, mas);
    workload.print();
    mas.print();

    balancer.initialDistribution();
    balancer.printDistribution();

    double totalTime = balancer.simulateExecution(true);
    cout << "Общее время выполнения: " << totalTime << endl;
}

void testCase4() {
    cout << "\n=========== ТЕСТ 4: Сравнение с/без перераспределения ===========" << endl;

    WorkloadModel workload;
    MASModel mas;

    for (int i = 0; i < 4; i++) {
        workload.addModule(i, 8.0);
    }
    workload.addDependency(0, 1);
    workload.addDependency(0, 2);
    workload.addDependency(1, 3);
    workload.addDependency(2, 3);
    workload.identifyStartEndModules();

    mas.addAgent(0, 1.0);
    mas.addAgent(1, 1.0);
    mas.addConnection(0, 1);

    LoadBalancer balancer(workload, mas);
    workload.print();
    mas.print();

    cout << "\n--- Без перераспределения ---" << endl;
    balancer.initialDistribution();
    balancer.printDistribution();
    double timeWithout = balancer.simulateExecution(false);
    cout << "Общее время выполнения: " << timeWithout << endl;

    WorkloadModel workload2 = workload;
    MASModel mas2 = mas;
    LoadBalancer balancer2(workload2, mas2);

    cout << "\n--- С перераспределением ---" << endl;
    balancer2.initialDistribution();
    balancer2.printDistribution();
    double timeWith = balancer2.simulateExecution(true);
    cout << "Общее время выполнения: " << timeWith << endl;

    cout << "\nЭффективность перераспределения: "
        << (timeWithout - timeWith) / timeWithout * 100 << "%" << endl;
}

int main() {
    setlocale(LC_ALL, "Russian");

    cout << "Модель многоагентной системы для распределения нагрузки" << endl;
    cout << "======================================================" << endl;
    testCase1();
    testCase2();
    testCase3();
    testCase4();
    return 0;
}