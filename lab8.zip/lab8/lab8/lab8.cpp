﻿#include <iostream>
#include <vector>
#include <map>
#include <random>
#include <algorithm>
#include <fstream>
#include <ctime>
#include <cmath>
#include <memory>

using namespace std;

const int MAX_LEVEL = 10;
const double L = 100.0;
const int T = 1000;
const int titer = 10;

enum EffectType {
    EFFECT_BALANCE_MULTIPLY,
    EFFECT_INCOME_MULTIPLY,
    EFFECT_ADD_LEVELS,
    EFFECT_INCOME_PLUS_PERCENT, 
    EFFECT_EXP_PLUS_PERCENT,
    EFFECT_BALANCE_PLUS_PERCENT,
    EFFECT_EXPENSE_MINUS_PERCENT, 
    EFFECT_EXPENSE_MINUS_BALANCE
};

enum DurationType {
    DURATION_ONCE,
    DURATION_ITERATIONS,
    DURATION_CYCLES,
    DURATION_UNTIL_NEXT_AUCTION,
    DURATION_COMPLEX
};

// Структура эффекта
struct Effect {
    EffectType type;
    double value1;
    double value2 = 0;
    DurationType duration_type;
    int duration = 0;
};

struct Artifact {
    int id;
    vector<Effect> effects;
    double base_cost;
    double current_cost;
    bool used;
    bool active;
    int remaining_duration;
    int owner_id = -1;

    Artifact(int i, const vector<Effect>& efs, double cost)
        : id(i), effects(efs), base_cost(cost), current_cost(cost),
        used(false), active(false), remaining_duration(0) {}
};

class Colony {
public:
    int id;
    int level;
    double balance;
    double base_expenses;
    double base_income;
    double current_expenses;
    double current_income;
    double experience;
    bool alive;
    bool has_active_artifact;
    shared_ptr<Artifact> current_artifact;
    vector<shared_ptr<Artifact>> owned_artifacts;

    Colony(int id, double start_balance, double base_income, double base_expenses)
        : id(id), level(1), balance(start_balance), base_expenses(base_expenses),
        base_income(base_income), current_expenses(base_expenses),
        current_income(base_income), experience(0), alive(true),
        has_active_artifact(false) {}

    void update_balance_cycle_start() {
        if (!alive) return;

        double previous_balance = balance;

        balance += current_income - current_expenses;

        experience += (balance - previous_balance);
        if (experience < 0) experience = 0;

        if (experience >= L && level < MAX_LEVEL) {
            level++;
            experience = 0;
            cout << "Colony " << id << " reached level " << level << endl;
        }

        if (balance < 0) {
            bool saved = false;
            for (auto& artifact : owned_artifacts) {
                if (!artifact->used) {
                    for (const auto& effect : artifact->effects) {
                        if (effect.type == EFFECT_BALANCE_PLUS_PERCENT ||
                            effect.type == EFFECT_BALANCE_MULTIPLY) {
                            apply_artifact_effect(artifact, effect);
                            artifact->used = true;
                            saved = true;
                            cout << "Colony " << id << " saved from destruction by artifact "
                                << artifact->id << endl;
                            break;
                        }
                    }
                    if (saved) break;
                }
            }

            if (!saved) {
                alive = false;
                cout << "Colony " << id << " destroyed! Balance: " << balance << endl;
            }
        }
    }

    void update_artifacts_end_of_cycle() {
        for (auto it = owned_artifacts.begin(); it != owned_artifacts.end();) {
            auto& artifact = *it;

            if (artifact->active && artifact->remaining_duration > 0) {
                artifact->remaining_duration--;

                if (artifact->remaining_duration == 0) {
                    for (const auto& effect : artifact->effects) {
                        revert_artifact_effect(artifact, effect);
                    }
                    artifact->active = false;
                    artifact->used = true;
                    it = owned_artifacts.erase(it);
                    continue;
                }
            }
            ++it;
        }

        has_active_artifact = !owned_artifacts.empty() &&
            any_of(owned_artifacts.begin(), owned_artifacts.end(),
                [](const shared_ptr<Artifact>& a) { return a->active; });
    }

    void apply_artifact_effect(const shared_ptr<Artifact>& artifact, const Effect& effect) {
        switch (effect.type) {
        case EFFECT_BALANCE_MULTIPLY:
            balance *= (1.0 + effect.value1);
            break;

        case EFFECT_INCOME_MULTIPLY:
            if (effect.duration_type == DURATION_ONCE) {
                current_income *= (1.0 + effect.value1);
            }
            else {
                current_income *= (1.0 + effect.value1);
            }
            break;

        case EFFECT_ADD_LEVELS:
            level = min(MAX_LEVEL, level + (int)effect.value1);
            break;

        case EFFECT_INCOME_PLUS_PERCENT:
            current_income += current_expenses * (effect.value1 / 100.0);
            break;

        case EFFECT_EXP_PLUS_PERCENT:
            experience += L * (effect.value1 / 100.0);
            if (experience >= L && level < MAX_LEVEL) {
                level++;
                experience = 0;
            }
            break;

        case EFFECT_BALANCE_PLUS_PERCENT:
            balance += current_income * (effect.value1 / 100.0);
            break;

        case EFFECT_EXPENSE_MINUS_PERCENT:
            current_expenses -= current_expenses * (effect.value1 / 100.0);
            if (current_expenses < base_income * 0.1) {
                current_expenses = base_income * 0.1;
            }
            break;

        case EFFECT_EXPENSE_MINUS_BALANCE:
            current_expenses -= balance * (effect.value1 / 100.0);
            if (current_expenses < 0) current_expenses = 0;
            break;
        }
    }

    void revert_artifact_effect(const shared_ptr<Artifact>& artifact, const Effect& effect) {
        switch (effect.type) {
        case EFFECT_INCOME_MULTIPLY:
            if (effect.duration_type != DURATION_ONCE) {
                current_income /= (1.0 + effect.value1);
            }
            break;

        case EFFECT_INCOME_PLUS_PERCENT:
            current_income -= current_expenses * (effect.value1 / 100.0);
            break;

        case EFFECT_EXPENSE_MINUS_PERCENT:
            current_expenses = base_expenses;
            break;

        case EFFECT_EXPENSE_MINUS_BALANCE:
            current_expenses = base_expenses;
            break;

        default:
            break;
        }
    }

    double evaluate_artifact_utility(const Artifact& artifact) const {
        if (!alive) return 0;

        double utility = 0;

        for (const auto& effect : artifact.effects) {
            double effect_utility = 0;

            switch (effect.type) {
            case EFFECT_BALANCE_MULTIPLY:
                effect_utility = balance * effect.value1 * 100;
                break;

            case EFFECT_INCOME_MULTIPLY:
                if (effect.duration_type == DURATION_ONCE) {
                    effect_utility = current_income * effect.value1 * 50;
                }
                else {
                    effect_utility = current_income * effect.value1 * effect.duration * 10;
                }
                break;

            case EFFECT_ADD_LEVELS:
                effect_utility = (MAX_LEVEL - level) * 1000 * effect.value1;
                break;

            case EFFECT_INCOME_PLUS_PERCENT:
                effect_utility = current_expenses * (effect.value1 / 100.0) * effect.duration * 20;
                break;

            case EFFECT_EXP_PLUS_PERCENT:
                effect_utility = L * (effect.value1 / 100.0) * 5;
                break;

            case EFFECT_BALANCE_PLUS_PERCENT:
                effect_utility = current_income * (effect.value1 / 100.0) * effect.duration * 15;
                break;

            case EFFECT_EXPENSE_MINUS_PERCENT:
                effect_utility = current_expenses * (effect.value1 / 100.0) * 500;
                break;

            case EFFECT_EXPENSE_MINUS_BALANCE:
                effect_utility = min(balance, current_expenses) * (effect.value1 / 100.0) * 300;
                break;
            }

            utility += effect_utility;
        }

        utility -= artifact.current_cost * 0.8;

        if (balance < current_expenses * 3) {
            utility *= 1.5;
        }

        return max(0.0, utility);
    }

    double determine_bid(const Artifact& artifact, int cycles_until_next_auction) {
        if (!alive) return 0;

        double utility = evaluate_artifact_utility(artifact);

        double max_affordable = balance - (current_expenses - current_income) * cycles_until_next_auction;

        double safety_margin = current_expenses * 2;
        max_affordable -= safety_margin;

        if (max_affordable < 0) max_affordable = 0;

        double bid = min(utility, max_affordable);

        if (bid < artifact.base_cost * 0.3) {
            return 0;
        }

        bid = min(bid, artifact.base_cost * 2);

        return bid;
    }

    void apply_artifact(shared_ptr<Artifact> artifact) {
        if (!artifact || !alive) return;

        balance -= artifact->current_cost;
        artifact->owner_id = id;
        artifact->active = true;

        if (!artifact->effects.empty()) {
            const auto& first_effect = artifact->effects[0];
            if (first_effect.duration_type == DURATION_ITERATIONS) {
                artifact->remaining_duration = first_effect.duration * titer;
            }
            else if (first_effect.duration_type == DURATION_CYCLES) {
                artifact->remaining_duration = first_effect.duration;
            }
            else if (first_effect.duration_type == DURATION_COMPLEX) {
                artifact->remaining_duration = first_effect.duration +
                    first_effect.value2 * titer;
            }
            else {
                artifact->remaining_duration = 1;
            }
        }

        for (const auto& effect : artifact->effects) {
            apply_artifact_effect(artifact, effect);
        }

        owned_artifacts.push_back(artifact);
        has_active_artifact = true;

        cout << "Colony " << id << " applied artifact " << artifact->id
            << ", new balance: " << balance << endl;
    }
};

random_device rd;
mt19937 gen(rd());

void conduct_auction(vector<Colony>& colonies, shared_ptr<Artifact> artifact,
    int cycles_until_next_auction, int auction_cycle) {
    vector<pair<double, int>> bids;

    for (auto& colony : colonies) {
        if (colony.alive && !colony.has_active_artifact) {
            double bid = colony.determine_bid(*artifact, cycles_until_next_auction);
            if (bid > 0) {
                bids.push_back({ bid, colony.id });
            }
        }
    }

    if (bids.empty()) {
        cout << "Auction " << auction_cycle << ": No bids for artifact " << artifact->id << endl;
        return;
    }

    sort(bids.rbegin(), bids.rend());

    double winning_bid = bids[0].first;
    double payment = (bids.size() > 1) ? bids[1].first : artifact->base_cost;

    int winner_id = bids[0].second;
    artifact->current_cost = payment;

    for (auto& colony : colonies) {
        if (colony.id == winner_id) {
            colony.apply_artifact(artifact);
            cout << "Auction " << auction_cycle << ": Colony " << colony.id
                << " won artifact " << artifact->id
                << " with bid " << winning_bid << ", paid " << payment << endl;
            break;
        }
    }
}

vector<shared_ptr<Artifact>> create_artifacts() {
    vector<shared_ptr<Artifact>> artifacts;

    artifacts.push_back(make_shared<Artifact>(38, vector<Effect>{
        {EFFECT_BALANCE_MULTIPLY, 1.0, 0, DURATION_ITERATIONS, 5}
    }, 250));

    artifacts.push_back(make_shared<Artifact>(39, vector<Effect>{
        {EFFECT_INCOME_MULTIPLY, 1.0, 0, DURATION_ONCE, 0},
        { EFFECT_ADD_LEVELS, 2.0, 0, DURATION_COMPLEX, 3 },
        { EFFECT_BALANCE_MULTIPLY, 1.0, 0, DURATION_CYCLES, 4 }
    }, 400));

    artifacts.push_back(make_shared<Artifact>(40, vector<Effect>{
        {EFFECT_INCOME_PLUS_PERCENT, 20.0, 0, DURATION_UNTIL_NEXT_AUCTION, 0},
        { EFFECT_EXP_PLUS_PERCENT, 30.0, 0, DURATION_COMPLEX, 2 },
        { EFFECT_BALANCE_PLUS_PERCENT, 15.0, 0, DURATION_CYCLES, 3 }
    }, 350));

    artifacts.push_back(make_shared<Artifact>(54, vector<Effect>{
        {EFFECT_EXPENSE_MINUS_PERCENT, 25.0, 0, DURATION_ONCE, 0}
    }, 200));

    artifacts.push_back(make_shared<Artifact>(61, vector<Effect>{
        {EFFECT_EXPENSE_MINUS_BALANCE, 10.0, 0, DURATION_UNTIL_NEXT_AUCTION, 0}
    }, 150));

    return artifacts;
}

void simulate_experiment(int num_colonies, double start_balance,
    int ta, int te, int& winners, int& losers,
    vector<int>& lifetimes, ofstream& log_file) {

    vector<Colony> colonies;
    uniform_real_distribution<> income_dist(150, 250);
    uniform_real_distribution<> expense_dist(50, 150);

    for (int i = 0; i < num_colonies; i++) {
        double income = income_dist(gen);
        double expenses = expense_dist(gen);
        while (income <= expenses * 1.2) {
            income = income_dist(gen);
        }
        colonies.push_back(Colony(i, start_balance, income, expenses));
    }

    auto all_artifacts = create_artifacts();
    vector<shared_ptr<Artifact>> available_artifacts = all_artifacts;

    double storm_income_reduction = 30;
    double storm_expense_increase = 20;
    double renaissance_income_boost = 40;
    double renaissance_expense_reduction = 25;

    bool event_active = false;
    int event_duration = 0;
    bool is_storm_event = false;

    for (int cycle = 0; cycle < T; cycle++) {
        log_file << "Cycle " << cycle << ": ";

        if (cycle % te == 0 && cycle > 0) {
            uniform_int_distribution<> event_dist(0, 1);
            is_storm_event = (event_dist(gen) == 0);
            event_active = true;
            event_duration = 1;

            for (auto& colony : colonies) {
                if (colony.alive) {
                    if (is_storm_event) {
                        colony.current_income -= storm_income_reduction;
                        colony.current_expenses += storm_expense_increase;
                        log_file << "Dust storm event. ";
                    }
                    else {
                        colony.current_income += renaissance_income_boost;
                        colony.current_expenses -= renaissance_expense_reduction;
                        log_file << "Renaissance event. ";
                    }
                }
            }
        }

        if (event_active && event_duration > 0) {
            event_duration--;
            if (event_duration == 0) {
                for (auto& colony : colonies) {
                    if (colony.alive) {
                        if (is_storm_event) {
                            colony.current_income += storm_income_reduction;
                            colony.current_expenses -= storm_expense_increase;
                        }
                        else {
                            colony.current_income -= renaissance_income_boost;
                            colony.current_expenses += renaissance_expense_reduction;
                        }
                    }
                }
                event_active = false;
            }
        }

        if (cycle % ta == 0 && cycle > 0 && !available_artifacts.empty()) {
            log_file << "Auction. ";

            uniform_int_distribution<> artifact_dist(0, available_artifacts.size() - 1);
            int artifact_idx = artifact_dist(gen);
            auto artifact = available_artifacts[artifact_idx];

            if (!artifact->used) {
                int cycles_until_next_auction = ta;
                conduct_auction(colonies, artifact, cycles_until_next_auction, cycle);

                available_artifacts.erase(available_artifacts.begin() + artifact_idx);
            }
        }

        int alive_count = 0;
        for (auto& colony : colonies) {
            if (colony.alive) {
                double prev_balance = colony.balance;
                colony.update_balance_cycle_start();

                if (colony.level >= MAX_LEVEL) {
                    colony.alive = false;
                    winners++;
                    lifetimes.push_back(cycle);
                    log_file << "Colony " << colony.id << " WON at level " << colony.level << ". ";
                }
                else if (!colony.alive) {
                    losers++;
                    lifetimes.push_back(cycle);
                    log_file << "Colony " << colony.id << " LOST. ";
                }
                else {
                    alive_count++;
                }
                colony.update_artifacts_end_of_cycle();
            }
        }

        log_file << "Alive: " << alive_count << endl;

        if (alive_count == 0) {
            break;
        }
    }

    for (const auto& colony : colonies) {
        if (colony.alive) {
            lifetimes.push_back(T);
            if (colony.level >= MAX_LEVEL) {
                winners++;
            }
            else {
                losers++;
            }
        }
    }
}

int main() {
    int num_experiments = 100;
    int num_colonies_per_experiment = 10;
    double start_balance = 1000;

    int ta = 25;
    int te = 30;

    ofstream log_file("simulation_log.txt");
    ofstream results_file("results.csv");
    ofstream winloss_file("win_loss_stats.csv");

    if (!log_file || !results_file || !winloss_file) {
        cerr << "Error opening output files!" << endl;
        return 1;
    }

    results_file << "Experiment,ColonyID,Lifetime,Result,FinalLevel,FinalBalance\n";
    winloss_file << "Parameter,Value,TotalColonies,Winners,Losers,WinRate,AvgLifetime\n";

    vector<int> all_lifetimes;
    map<int, int> lifetime_distribution;
    int total_winners_all = 0;
    int total_losers_all = 0;

    log_file << "=== Starting Simulation ===" << endl;
    log_file << "Experiments: " << num_experiments << endl;
    log_file << "Colonies per experiment: " << num_colonies_per_experiment << endl;
    log_file << "Start balance: " << start_balance << endl;
    log_file << "Auction period: " << ta << endl;
    log_file << "Event period: " << te << endl;

    for (int exp = 0; exp < num_experiments; exp++) {
        log_file << "\n=== Experiment " << exp + 1 << " ===" << endl;

        int winners = 0;
        int losers = 0;
        vector<int> lifetimes;

        simulate_experiment(num_colonies_per_experiment, start_balance,
            ta, te, winners, losers, lifetimes, log_file);

        total_winners_all += winners;
        total_losers_all += losers;
        all_lifetimes.insert(all_lifetimes.end(), lifetimes.begin(), lifetimes.end());

        for (size_t i = 0; i < lifetimes.size(); i++) {
            results_file << exp << "," << i << "," << lifetimes[i] << ",";
            if (i < (size_t)winners) {
                results_file << "WIN," << MAX_LEVEL << ",N/A\n";
            }
            else {
                results_file << "LOSE,1,N/A\n";
            }
        }

        cout << "Experiment " << exp + 1 << " completed: "
            << winners << " winners, " << losers << " losers" << endl;
    }

    log_file << "\n=== Balance Analysis ===" << endl;
    vector<double> test_balances = { 500.0, 1000.0, 1500.0, 2000.0 };

    for (double balance : test_balances) {
        int test_winners = 0;
        int test_losers = 0;
        vector<int> test_lifetimes;
        ofstream temp_log("temp_log.txt");

        simulate_experiment(20, balance, ta, te,
            test_winners, test_losers, test_lifetimes, temp_log);

        double win_rate = (double)test_winners / (test_winners + test_losers);
        double avg_lifetime = 0;
        if (!test_lifetimes.empty()) {
            for (int lt : test_lifetimes) avg_lifetime += lt;
            avg_lifetime /= test_lifetimes.size();
        }

        winloss_file << "StartBalance," << balance << ","
            << (test_winners + test_losers) << ","
            << test_winners << "," << test_losers << ","
            << win_rate << "," << avg_lifetime << "\n";

        log_file << "Balance " << balance << ": " << test_winners
            << " wins, " << test_losers << " losses, rate: "
            << win_rate * 100 << "%" << endl;
    }

    log_file << "\n=== Auction Period Analysis ===" << endl;
    vector<int> test_periods = { 15, 25, 35, 50 };

    for (int period : test_periods) {
        int test_winners = 0;
        int test_losers = 0;
        vector<int> test_lifetimes;
        ofstream temp_log("temp_log.txt");

        simulate_experiment(20, start_balance, period, te,
            test_winners, test_losers, test_lifetimes, temp_log);

        double win_rate = (double)test_winners / (test_winners + test_losers);
        double avg_lifetime = 0;
        if (!test_lifetimes.empty()) {
            for (int lt : test_lifetimes) avg_lifetime += lt;
            avg_lifetime /= test_lifetimes.size();
        }

        winloss_file << "AuctionPeriod," << period << ","
            << (test_winners + test_losers) << ","
            << test_winners << "," << test_losers << ","
            << win_rate << "," << avg_lifetime << "\n";

        log_file << "Period " << period << ": " << test_winners
            << " wins, " << test_losers << " losses, rate: "
            << win_rate * 100 << "%" << endl;
    }

    for (int lifetime : all_lifetimes) {
        int bucket = (lifetime / 50) * 50;
        lifetime_distribution[bucket]++;
    }

    ofstream dist_file("lifetime_distribution.csv");
    dist_file << "LifetimeBucket,Count,Probability\n";

    int total_cases = all_lifetimes.size();
    for (const auto& entry : lifetime_distribution) {
        double probability = (double)entry.second / total_cases;
        dist_file << entry.first << "," << entry.second << "," << probability << "\n";
    }

    cout << "\n=== Final Statistics ===" << endl;
    cout << "Total experiments: " << num_experiments << endl;
    cout << "Total colonies simulated: " << num_experiments * num_colonies_per_experiment << endl;
    cout << "Total winners: " << total_winners_all << endl;
    cout << "Total losers: " << total_losers_all << endl;
    cout << "Overall win rate: "
        << (double)total_winners_all / (total_winners_all + total_losers_all) * 100
        << "%" << endl;

    log_file.close();
    results_file.close();
    winloss_file.close();
    dist_file.close();

    cout << "\nResults saved to:" << endl;
    cout << "  simulation_log.txt - детальный лог симуляции" << endl;
    cout << "  results.csv - результаты каждого эксперимента" << endl;
    cout << "  win_loss_stats.csv - статистика побед/поражений" << endl;
    cout << "  lifetime_distribution.csv - распределение времени жизни" << endl;

    return 0;
}