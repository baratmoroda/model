﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
#include <map>
#include <string>
#include <cmath>

using namespace std;

// Константы игры
const int NUM_PLAYERS = 4;
const int INITIAL_HAND_SIZE = 6;
const int NUM_SUITS = 4;
const int NUM_RANKS = 13;

// Структура карты
struct Card {
    int suit;
    int rank;

    bool operator==(const Card& other) const {
        return suit == other.suit && rank == other.rank;
    }

    string toString() const {
        static const string suits[] = { "♠", "♣", "♦", "♥" };
        static const string ranks[] = { "2", "3", "4", "5", "6", "7", "8",
                                        "9", "10", "J", "Q", "K", "A" };
        return ranks[rank] + suits[suit];
    }
};

enum AlgorithmType {
    RANDOM,
    AGGRESSIVE
};

class Agent {
private:
    int id;
    int partnerId;
    AlgorithmType algorithm;
    vector<Card> hand;

public:
    Agent(int id, int partnerId, AlgorithmType algo)
        : id(id), partnerId(partnerId), algorithm(algo) {}

    const vector<Card>& getHand() const { return hand; }
    int getId() const { return id; }

    void addCard(const Card& card) { hand.push_back(card); }
    void removeCard(const Card& card) {
        hand.erase(remove(hand.begin(), hand.end(), card), hand.end());
    }
    void takeCards(const vector<Card>& cards) {
        hand.insert(hand.end(), cards.begin(), cards.end());
    }
    bool hasCards() const { return !hand.empty(); }

    Card chooseAttackCard(const vector<Card>& tableCards, Card trump) {
        if (hand.empty()) return { -1, -1 };

        if (algorithm == RANDOM) {
            random_device rd;
            mt19937 gen(rd());
            uniform_int_distribution<> dis(0, hand.size() - 1);
            return hand[dis(gen)];
        }
        else {
            vector<Card> nonTrump;
            for (const auto& card : hand) {
                if (card.suit != trump.suit) {
                    nonTrump.push_back(card);
                }
            }

            if (!nonTrump.empty()) {
                auto minCard = *min_element(nonTrump.begin(), nonTrump.end(),
                    [](const Card& a, const Card& b) { return a.rank < b.rank; });
                return minCard;
            }
            else {
                return *min_element(hand.begin(), hand.end(),
                    [](const Card& a, const Card& b) { return a.rank < b.rank; });
            }
        }
    }

    Card canTransfer(const Card& attackCard, Card trump) {
        for (const auto& card : hand) {
            if (card.rank == attackCard.rank && card.suit != attackCard.suit) {
                return card;
            }
        }
        return { -1, -1 };
    }

    Card chooseDefendCard(const Card& attackCard, Card trump) {
        for (const auto& card : hand) {
            if (card.suit == attackCard.suit && card.rank > attackCard.rank) {
                return card;
            }
        }

        if (attackCard.suit != trump.suit) {
            for (const auto& card : hand) {
                if (card.suit == trump.suit) {
                    return card;
                }
            }
        }

        if (attackCard.suit == trump.suit) {
            for (const auto& card : hand) {
                if (card.suit == trump.suit && card.rank > attackCard.rank) {
                    return card;
                }
            }
        }

        return { -1, -1 };
    }

    vector<Card> getPossibleThrows(const vector<Card>& tableCards) {
        vector<Card> possibleThrows;

        if (tableCards.empty()) return possibleThrows;

        vector<int> tableRanks;
        for (const auto& card : tableCards) {
            tableRanks.push_back(card.rank);
        }

        for (const auto& card : hand) {
            if (find(tableRanks.begin(), tableRanks.end(), card.rank) != tableRanks.end()) {
                possibleThrows.push_back(card);
            }
        }

        return possibleThrows;
    }

    Card chooseThrowCard(const vector<Card>& tableCards) {
        auto possibleThrows = getPossibleThrows(tableCards);
        if (possibleThrows.empty()) return { -1, -1 };

        if (algorithm == RANDOM) {
            random_device rd;
            mt19937 gen(rd());
            uniform_int_distribution<> dis(0, possibleThrows.size() - 1);
            return possibleThrows[dis(gen)];
        }
        else {
            return *min_element(possibleThrows.begin(), possibleThrows.end(),
                [](const Card& a, const Card& b) { return a.rank < b.rank; });
        }
    }

    bool shouldThrow(const vector<Card>& tableCards, const Agent& defender) {
        if (algorithm == RANDOM) {
            random_device rd;
            mt19937 gen(rd());
            uniform_int_distribution<> dis(0, 1);
            return dis(gen) == 1 && !getPossibleThrows(tableCards).empty();
        }
        else {
            return !getPossibleThrows(tableCards).empty() && defender.getHand().size() > 1;
        }
    }
};

class Game {
private:
    vector<Card> deck;
    vector<Card> discardPile;
    vector<Card> tableCards;
    vector<Agent> agents;
    Card trumpCard;
    int attackingPair;
    int leadAttacker;
    int currentDefender;

public:
    Game(AlgorithmType algo1, AlgorithmType algo2) {
        for (int suit = 0; suit < NUM_SUITS; suit++) {
            for (int rank = 0; rank < NUM_RANKS; rank++) {
                deck.push_back({ suit, rank });
            }
        }

        agents.push_back(Agent(0, 1, algo1));
        agents.push_back(Agent(1, 0, algo1));
        agents.push_back(Agent(2, 3, algo2));
        agents.push_back(Agent(3, 2, algo2));
    }

    void initialize() {
        random_device rd;
        mt19937 gen(rd());
        shuffle(deck.begin(), deck.end(), gen);

        trumpCard = deck.back();

        for (int i = 0; i < INITIAL_HAND_SIZE; i++) {
            for (int j = 0; j < NUM_PLAYERS; j++) {
                if (!deck.empty()) {
                    agents[j].addCard(deck.back());
                    deck.pop_back();
                }
            }
        }

        int firstAttacker = -1;
        Card minTrump = { NUM_SUITS, NUM_RANKS };

        for (int i = 0; i < NUM_PLAYERS; i++) {
            for (const auto& card : agents[i].getHand()) {
                if (card.suit == trumpCard.suit) {
                    if (card.rank < minTrump.rank) {
                        minTrump = card;
                        firstAttacker = i;
                    }
                }
            }
        }

        if (firstAttacker == -1) {
            uniform_int_distribution<> dis(0, NUM_PLAYERS - 1);
            firstAttacker = dis(gen);
        }

        attackingPair = firstAttacker / 2;
        leadAttacker = firstAttacker;

        currentDefender = (firstAttacker % 2 == 0) ?
            ((firstAttacker + 2) % NUM_PLAYERS) :
            ((firstAttacker + 2) % NUM_PLAYERS);
    }

    bool isGameOver() const {
        bool pair1Empty = !agents[0].hasCards() && !agents[1].hasCards();
        bool pair2Empty = !agents[2].hasCards() && !agents[3].hasCards();
        return pair1Empty || pair2Empty;
    }

    int getWinner() const {
        if (!agents[0].hasCards() && !agents[1].hasCards()) return 0;
        if (!agents[2].hasCards() && !agents[3].hasCards()) return 1;
        return -1;
    }

    void replenishHands() {
        for (int i = 0; i < NUM_PLAYERS; i++) {
            while (agents[i].getHand().size() < INITIAL_HAND_SIZE && !deck.empty()) {
                agents[i].addCard(deck.back());
                deck.pop_back();
            }
        }
    }

    void clearTable() {
        discardPile.insert(discardPile.end(), tableCards.begin(), tableCards.end());
        tableCards.clear();
    }

    void playRound() {
        if (isGameOver()) return;

        tableCards.clear();

        int attacker = leadAttacker;
        int defender = currentDefender;
        int partner = (attacker % 2 == 0) ? attacker + 1 : attacker - 1;

        Card attackCard = agents[attacker].chooseAttackCard(tableCards, trumpCard);
        if (attackCard.suit == -1) return;

        agents[attacker].removeCard(attackCard);
        tableCards.push_back(attackCard);

        Card transferCard = agents[defender].canTransfer(attackCard, trumpCard);
        if (transferCard.suit != -1) {
            agents[defender].removeCard(transferCard);
            tableCards.push_back(transferCard);

            swap(attacker, defender);
            partner = (attacker % 2 == 0) ? attacker + 1 : attacker - 1;
        }

        bool defenderTookCards = false;
        bool canThrow = true;

        while (true) {
            Card defendCard = agents[defender].chooseDefendCard(attackCard, trumpCard);

            if (defendCard.suit == -1) {
                agents[defender].takeCards(tableCards);
                defenderTookCards = true;
                break;
            }
            else {
                agents[defender].removeCard(defendCard);
                tableCards.push_back(defendCard);

                if (!canThrow || agents[defender].getHand().empty()) {
                    break;
                }

                if (agents[attacker].shouldThrow(tableCards, agents[defender])) {
                    Card throwCard = agents[attacker].chooseThrowCard(tableCards);
                    if (throwCard.suit != -1) {
                        agents[attacker].removeCard(throwCard);
                        tableCards.push_back(throwCard);
                        attackCard = throwCard;
                        continue;
                    }
                }

                if (agents[partner].shouldThrow(tableCards, agents[defender])) {
                    Card throwCard = agents[partner].chooseThrowCard(tableCards);
                    if (throwCard.suit != -1) {
                        agents[partner].removeCard(throwCard);
                        tableCards.push_back(throwCard);
                        attackCard = throwCard;
                        continue;
                    }
                }

                break;
            }
        }

        if (!defenderTookCards) {
            clearTable();

            attackingPair = attacker / 2;
            leadAttacker = defender;

            int nextPlayer = (defender + 1) % NUM_PLAYERS;
            while (nextPlayer / 2 == attackingPair) {
                nextPlayer = (nextPlayer + 1) % NUM_PLAYERS;
            }
            currentDefender = nextPlayer;
        }
        else {
            attackingPair = defender / 2;
            leadAttacker = defender;

            int nextDefender = (defender + 1) % NUM_PLAYERS;
            while (nextDefender / 2 == attackingPair) {
                nextDefender = (nextDefender + 1) % NUM_PLAYERS;
            }
            currentDefender = nextDefender;
        }

        replenishHands();

        if (!agents[leadAttacker].hasCards()) {
            leadAttacker = (leadAttacker % 2 == 0) ? leadAttacker + 1 : leadAttacker - 1;
        }
    }

    int playGame() {
        initialize();

        int round = 0;
        while (!isGameOver() && round < 1000) {
            playRound();
            round++;
        }

        return getWinner();
    }

    void printState() const {
        cout << "Козырь: " << trumpCard.toString() << endl;
        cout << "Карт в колоде: " << deck.size() << endl;
        cout << "Карт в бито: " << discardPile.size() << endl;

        for (int i = 0; i < NUM_PLAYERS; i++) {
            cout << "Игрок " << i << " (";
            if (i / 2 == 0) cout << "Пара 1, ";
            else cout << "Пара 2, ";

            if (agents[i].getHand().empty()) {
                cout << "без карт): ";
            }
            else {
                cout << agents[i].getHand().size() << " карт): ";
                for (const auto& card : agents[i].getHand()) {
                    cout << card.toString() << " ";
                }
            }
            cout << endl;
        }
    }
};

int main() {
    setlocale(LC_ALL, "Rus");
    cout << "Эксперимент: Подкидной дурак с разными алгоритмами\n";
    cout << "==================================================\n\n";

    const int NUM_EXPERIMENTS = 1000;
    int winsPair1 = 0;
    int winsPair2 = 0;

    for (int i = 0; i < NUM_EXPERIMENTS; i++) {
        if (i % 100 == 0) {
            cout << "Проведено " << i << " игр..." << endl;
        }

        Game game(RANDOM, AGGRESSIVE);
        int winner = game.playGame();

        if (winner == 0) {
            winsPair1++;
        }
        else if (winner == 1) {
            winsPair2++;
        }
    }

    cout << "\nРезультаты после " << NUM_EXPERIMENTS << " игр:\n";
    cout << "==================================================\n";
    cout << "Пара 1 (случайные ходы): " << winsPair1 << " побед ("
        << (winsPair1 * 100.0 / NUM_EXPERIMENTS) << "%)\n";
    cout << "Пара 2 (агрессивные ходы): " << winsPair2 << " побед ("
        << (winsPair2 * 100.0 / NUM_EXPERIMENTS) << "%)\n";

    double p1 = winsPair1 * 1.0 / NUM_EXPERIMENTS;
    double p2 = winsPair2 * 1.0 / NUM_EXPERIMENTS;
    double se = sqrt((p1 * (1 - p1) + p2 * (1 - p2)) / NUM_EXPERIMENTS);
    double z = (p2 - p1) / se;

    cout << "\nСтатистический анализ:\n";
    cout << "Разница: " << (p2 - p1) * 100 << "% в пользу ";
    if (p2 > p1) {
        cout << "агрессивного алгоритма\n";
    }
    else {
        cout << "случайного алгоритма\n";
    }

    if (abs(z) > 1.96) {
        cout << "Разница статистически значима (95% доверительный интервал)\n";
    }
    else {
        cout << "Разница не статистически значима\n";
    }

    cout << "\nДемонстрационная игра:\n";
    cout << "==================================================\n";
    Game demoGame(RANDOM, AGGRESSIVE);
    demoGame.initialize();
    demoGame.printState();

    cout << "\nИграем 5 раундов...\n";
    for (int i = 0; i < 5; i++) {
        cout << "\nРаунд " << i + 1 << ":\n";
        demoGame.playRound();
        demoGame.printState();

        if (demoGame.isGameOver()) {
            cout << "Игра окончена!\n";
            break;
        }
    }

    return 0;
}