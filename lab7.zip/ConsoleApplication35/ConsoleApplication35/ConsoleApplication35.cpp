﻿#include <iostream>
#include <vector>
#include <cmath>
#include <random>
#include <chrono>
#include <algorithm>

using namespace std;

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

mt19937 rng(static_cast<unsigned int>(chrono::steady_clock::now().time_since_epoch().count()));

const double AREA_SIZE = 100.0;
const double BASE_SPEED = 1.5;
const double FLEE_SPEED_MULT = 1.25;
const double INFECTED_SPEED_MULT = 0.9;
const double ZOMBIE_SPEED_MULT = 0.85;
const double ZOMBIE_VISION_ANGLE_MULT = 0.75;
const double ZOMBIE_VISION_RANGE_MULT = 1.1;
const double ACTION_ZONE_MULT = 0.93;

const int T_MOVE_MIN = 5;
const int T_MOVE_MAX = 20;
const int T_INC_MIN = 10;
const int T_INC_MAX = 30;

const double ZOMBIE_RECOVERY_CHANCE = 0.01;
const double RECOVERED_REINFECT_CHANCE = 0.25;

const double VISION_ANGLE_MIN = 90.0;
const double VISION_ANGLE_MAX = 150.0;
const double VISION_RANGE = 20.0;

enum class State { HEALTHY, INFECTED, ZOMBIE, RECOVERED };

struct Agent {
    double x, y;
    double vx, vy;
    double speed;
    State state;
    int moveTimeLeft;
    int incubTimeLeft;
    double visionAngle;
    double visionRange;
    int id;

    Agent(double x_, double y_, int id_) : x(x_), y(y_), id(id_), state(State::HEALTHY) {
        uniform_real_distribution<double> dir_dist(0.0, 2.0 * M_PI);
        double angle = dir_dist(rng);
        vx = cos(angle);
        vy = sin(angle);

        uniform_int_distribution<int> move_dist(T_MOVE_MIN, T_MOVE_MAX);
        moveTimeLeft = move_dist(rng);

        uniform_real_distribution<double> angle_dist(VISION_ANGLE_MIN, VISION_ANGLE_MAX);
        visionAngle = angle_dist(rng) * M_PI / 180.0;
        visionRange = VISION_RANGE;

        speed = BASE_SPEED;
        incubTimeLeft = 0;
    }

    void updateSpeed() {
        switch (state) {
        case State::HEALTHY: speed = BASE_SPEED; break;
        case State::INFECTED: speed = BASE_SPEED * INFECTED_SPEED_MULT; break;
        case State::ZOMBIE: speed = BASE_SPEED * ZOMBIE_SPEED_MULT; break;
        case State::RECOVERED: speed = BASE_SPEED; break;
        }
    }

    bool isInVisionSector(double tx, double ty) const {
        double dx = tx - x;
        double dy = ty - y;
        double dist_sq = dx * dx + dy * dy;
        if (dist_sq > visionRange * visionRange) return false;
        if (dist_sq < 0.001) return true;

        double dist = sqrt(dist_sq);
        dx /= dist;
        dy /= dist;
        double dot = vx * dx + vy * dy;
        double angle = acos(max(-1.0, min(1.0, dot)));
        return angle <= visionAngle / 2.0;
    }

    double getActionRange() const { return visionRange * ACTION_ZONE_MULT; }
    double getActionAngle() const { return visionAngle * ACTION_ZONE_MULT; }
};

double distanceSq(const Agent& a1, const Agent& a2) {
    double dx = a1.x - a2.x;
    double dy = a1.y - a2.y;
    return dx * dx + dy * dy;
}

class ZombieModel {
    vector<Agent> agents;
    int currentTime, totalTime, tInit, initInfected;
    bool simulationEnded;

public:
    ZombieModel(int n, int m, int tInit_, int totalTime_)
        : currentTime(0), tInit(tInit_), initInfected(m), totalTime(totalTime_), simulationEnded(false) {

        uniform_real_distribution<double> pos_dist(0.0, AREA_SIZE);
        for (int i = 0; i < n; ++i) {
            agents.emplace_back(pos_dist(rng), pos_dist(rng), i);
        }
    }

    void step() {
        if (simulationEnded || currentTime >= totalTime) {
            simulationEnded = true;
            return;
        }

        if (currentTime == tInit) infectRandomAgents();

        updateAgents();
        processInteractions();
        moveAgents();

        currentTime++;
        if (countHealthy() == 0) simulationEnded = true;
    }

    bool isEnded() const { return simulationEnded || currentTime >= totalTime; }
    int getCurrentTime() const { return currentTime; }
    int countHealthy() const {
        int count = 0;
        for (const auto& agent : agents)
            if (agent.state == State::HEALTHY) count++;
        return count;
    }

private:
    void infectRandomAgents() {
        vector<int> indices(agents.size());
        for (size_t i = 0; i < agents.size(); ++i) indices[i] = static_cast<int>(i);
        shuffle(indices.begin(), indices.end(), rng);

        uniform_int_distribution<int> inc_dist(T_INC_MIN, T_INC_MAX);
        int infectedCount = min(initInfected, static_cast<int>(agents.size()));

        for (int i = 0; i < infectedCount; ++i) {
            agents[indices[i]].state = State::INFECTED;
            agents[indices[i]].incubTimeLeft = inc_dist(rng);
            agents[indices[i]].updateSpeed();
        }
    }

    void updateAgents() {
        uniform_real_distribution<double> prob(0.0, 1.0);
        uniform_int_distribution<int> move_dist(T_MOVE_MIN, T_MOVE_MAX);
        uniform_real_distribution<double> dir_dist(0.0, 2.0 * M_PI);

        for (auto& agent : agents) {
            if (agent.moveTimeLeft > 0) agent.moveTimeLeft--;

            if (agent.moveTimeLeft == 0) {
                double angle = dir_dist(rng);
                agent.vx = cos(angle);
                agent.vy = sin(angle);
                agent.moveTimeLeft = move_dist(rng);
            }

            if (agent.state == State::INFECTED) {
                if (agent.incubTimeLeft > 0) {
                    agent.incubTimeLeft--;
                }
                else {
                    agent.state = State::ZOMBIE;
                    agent.visionAngle *= ZOMBIE_VISION_ANGLE_MULT;
                    agent.visionRange *= ZOMBIE_VISION_RANGE_MULT;
                    agent.updateSpeed();
                }
            }

            if (agent.state == State::ZOMBIE && prob(rng) < ZOMBIE_RECOVERY_CHANCE) {
                agent.state = State::RECOVERED;
                agent.visionAngle /= ZOMBIE_VISION_ANGLE_MULT;
                agent.visionRange /= ZOMBIE_VISION_RANGE_MULT;
                agent.updateSpeed();
            }
        }
    }

    void processInteractions() {
        uniform_real_distribution<double> prob(0.0, 1.0);

        for (size_t z_idx = 0; z_idx < agents.size(); ++z_idx) {
            auto& zombie = agents[z_idx];
            if (zombie.state != State::ZOMBIE) continue;

            double minDistSq = zombie.visionRange * zombie.visionRange;
            size_t targetIdx = agents.size();

            for (size_t i = 0; i < agents.size(); ++i) {
                auto& target = agents[i];
                if (target.id == zombie.id || target.state != State::HEALTHY) continue;

                double dist_sq = distanceSq(zombie, target);
                if (dist_sq <= minDistSq && zombie.isInVisionSector(target.x, target.y)) {
                    minDistSq = dist_sq;
                    targetIdx = i;
                }
            }

            if (targetIdx < agents.size()) {
                auto& target = agents[targetIdx];
                double dx = target.x - zombie.x;
                double dy = target.y - zombie.y;
                double dist = sqrt(minDistSq);
                if (dist > 0.001) {
                    zombie.vx = dx / dist;
                    zombie.vy = dy / dist;
                    zombie.moveTimeLeft = 1;
                }

                if (dist <= zombie.getActionRange()) {
                    double dot = zombie.vx * (dx / dist) + zombie.vy * (dy / dist);
                    double angle = acos(max(-1.0, min(1.0, dot)));

                    if (angle <= zombie.getActionAngle() / 2.0) {
                        uniform_int_distribution<int> inc_dist(T_INC_MIN, T_INC_MAX);
                        target.state = State::INFECTED;
                        target.incubTimeLeft = inc_dist(rng);
                        target.updateSpeed();
                    }
                }
            }

            for (auto& target : agents) {
                if (target.id == zombie.id || target.state != State::RECOVERED) continue;

                double dist_sq = distanceSq(zombie, target);
                if (dist_sq <= zombie.getActionRange() * zombie.getActionRange() &&
                    zombie.isInVisionSector(target.x, target.y) &&
                    prob(rng) < RECOVERED_REINFECT_CHANCE) {
                    target.state = State::ZOMBIE;
                    target.visionAngle *= ZOMBIE_VISION_ANGLE_MULT;
                    target.visionRange *= ZOMBIE_VISION_RANGE_MULT;
                    target.updateSpeed();
                }
            }
        }

        for (auto& healthy : agents) {
            if (healthy.state != State::HEALTHY) continue;

            bool leftZombie = false, rightZombie = false;

            for (const auto& zombie : agents) {
                if (zombie.id == healthy.id || zombie.state != State::ZOMBIE) continue;

                if (healthy.isInVisionSector(zombie.x, zombie.y)) {
                    double dx = zombie.x - healthy.x;
                    double dy = zombie.y - healthy.y;
                    double dist = sqrt(dx * dx + dy * dy);
                    dx /= dist;
                    dy /= dist;

                    double perp_x = -healthy.vy;
                    double perp_y = healthy.vx;
                    double side = dx * perp_x + dy * perp_y;

                    if (side >= 0) rightZombie = true;
                    else leftZombie = true;

                    if (leftZombie && rightZombie) break;
                }
            }

            if (leftZombie || rightZombie) {
                healthy.speed = BASE_SPEED * FLEE_SPEED_MULT;

                if (leftZombie && rightZombie) {
                    healthy.vx = -healthy.vx;
                    healthy.vy = -healthy.vy;
                }
                else if (leftZombie) {
                    double angle = -healthy.visionAngle / 4.0;
                    double new_vx = healthy.vx * cos(angle) - healthy.vy * sin(angle);
                    double new_vy = healthy.vx * sin(angle) + healthy.vy * cos(angle);
                    double len = sqrt(new_vx * new_vx + new_vy * new_vy);
                    healthy.vx = new_vx / len;
                    healthy.vy = new_vy / len;
                }
                else if (rightZombie) {
                    double angle = healthy.visionAngle / 4.0;
                    double new_vx = healthy.vx * cos(angle) - healthy.vy * sin(angle);
                    double new_vy = healthy.vx * sin(angle) + healthy.vy * cos(angle);
                    double len = sqrt(new_vx * new_vx + new_vy * new_vy);
                    healthy.vx = new_vx / len;
                    healthy.vy = new_vy / len;
                }
                healthy.moveTimeLeft = 1;
            }
            else {
                healthy.speed = BASE_SPEED;
            }
        }
    }

    void moveAgents() {
        for (auto& agent : agents) {
            double new_x = agent.x + agent.vx * agent.speed;
            double new_y = agent.y + agent.vy * agent.speed;

            if (new_x < 0) { agent.vx = fabs(agent.vx); new_x = 0; }
            else if (new_x > AREA_SIZE) { agent.vx = -fabs(agent.vx); new_x = AREA_SIZE; }

            if (new_y < 0) { agent.vy = fabs(agent.vy); new_y = 0; }
            else if (new_y > AREA_SIZE) { agent.vy = -fabs(agent.vy); new_y = AREA_SIZE; }

            agent.x = new_x;
            agent.y = new_y;
        }
    }
};

void runExperimentsForConfig(int n, int m, int experiments = 1000) {
    const int T_INIT = 5;
    const int TOTAL_TIME = 2000;

    long long totalTime = 0;
    int successfulRuns = 0;

    cout << "Конфигурация: n=" << n << ", m=" << m << " (" << experiments << " экспериментов)\n";

    auto start = chrono::steady_clock::now();

    for (int exp = 0; exp < experiments; ++exp) {
        ZombieModel model(n, m, T_INIT, TOTAL_TIME);

        while (!model.isEnded()) {
            model.step();
        }

        if (model.countHealthy() == 0) {
            totalTime += model.getCurrentTime();
            successfulRuns++;
        }

        if ((exp + 1) % 100 == 0) {
            cout << "  Прогресс: " << (exp + 1) << "/" << experiments << "\n";
        }
    }

    auto end = chrono::steady_clock::now();
    chrono::duration<double> elapsed = end - start;

    double avgTime = (successfulRuns > 0) ? static_cast<double>(totalTime) / successfulRuns : 0.0;
    double successRate = static_cast<double>(successfulRuns) / experiments * 100.0;

    cout << "  Результаты: среднее время = " << avgTime << " шагов, успешность = "
        << successRate << "% (" << successfulRuns << "/" << experiments << ")\n";
    cout << "  Время выполнения: " << elapsed.count() << " секунд\n\n";
}

int main() {
    setlocale(LC_ALL, "Rus");
    cout << "МОДЕЛИРОВАНИЕ РАСПРОСТРАНЕНИЯ ЗОМБИ-ИНФЕКЦИИ\n";
    cout << "=============================================\n\n";

    vector<pair<int, int>> configs = {
        {50, 1}, {50, 5}, {50, 10},
        {100, 1}, {100, 5}, {100, 10},
        {200, 1}, {200, 5}, {200, 10},
        {300, 1}, {300, 5}, {300, 10}
    };

    const int EXPERIMENTS_PER_CONFIG = 1000;

    cout << "Всего конфигураций: " << configs.size() << "\n";
    cout << "Экспериментов на конфигурацию: " << EXPERIMENTS_PER_CONFIG << "\n";
    cout << "Всего экспериментов: " << configs.size() * EXPERIMENTS_PER_CONFIG << "\n\n";

    auto totalStart = chrono::steady_clock::now();

    for (size_t i = 0; i < configs.size(); ++i) {
        auto& config = configs[i];
        cout << "[" << (i + 1) << "/" << configs.size() << "] ";
        runExperimentsForConfig(config.first, config.second, EXPERIMENTS_PER_CONFIG);
    }

    auto totalEnd = chrono::steady_clock::now();
    chrono::duration<double> totalElapsed = totalEnd - totalStart;

    cout << "=============================================\n";
    cout << "ВСЕ ЭКСПЕРИМЕНТЫ ЗАВЕРШЕНЫ\n";
    cout << "Общее время выполнения: " << totalElapsed.count() << " секунд\n";
    cout << "Среднее время на конфигурацию: " << totalElapsed.count() / configs.size() << " секунд\n";

    return 0;
}