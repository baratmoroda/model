using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace StabilityAnalysis
{
    public partial class MainForm : Form
    {
        private Chart[] charts;
        private const int CHART_COUNT = 6;
        private const double DEFAULT_DT = 0.01;
        private const double DEFAULT_T_STOP = 50.0;

        public MainForm()
        {
            InitializeComponent();
            InitializeCharts();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1400, 900);
            this.Text = "������ ������������ ������� � �������������";
            this.WindowState = FormWindowState.Maximized;
            this.ResumeLayout(false);
        }

        private void InitializeCharts()
        {
            charts = new Chart[CHART_COUNT];
            string[] titles = {
                "1. ����� �������� ������� (tau)",
                "2. ������� tau �� �������� �������",
                "3. ������� b �� �������� �������",
                "4. ������� a �� �������� �������",
                "5. ������� c �� �������� �������",
                "6. ������� k �� �������� �������"
            };

            TableLayoutPanel tableLayout = new TableLayoutPanel();
            tableLayout.Dock = DockStyle.Fill;
            tableLayout.RowCount = 2;
            tableLayout.ColumnCount = 3;
            tableLayout.RowStyles.Clear();
            tableLayout.ColumnStyles.Clear();

            for (int i = 0; i < 2; i++)
            {
                tableLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
            }
            for (int i = 0; i < 3; i++)
            {
                tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
            }

            this.Controls.Add(tableLayout);

            for (int i = 0; i < CHART_COUNT; i++)
            {
                charts[i] = CreateChart(titles[i]);
                tableLayout.Controls.Add(charts[i], i % 3, i / 3);
            }
        }

        private Chart CreateChart(string title)
        {
            Chart chart = new Chart();
            chart.Dock = DockStyle.Fill;

            ChartArea chartArea = new ChartArea();
            chartArea.AxisX.Title = "��������";
            chartArea.AxisY.Title = "��������";
            chartArea.AxisX.MajorGrid.Enabled = true;
            chartArea.AxisY.MajorGrid.Enabled = true;
            chartArea.AxisX.LabelStyle.Format = "F2";
            chartArea.AxisY.LabelStyle.Format = "F2";

            chart.ChartAreas.Add(chartArea);

            Title chartTitle = new Title(title, Docking.Top, new Font("Arial", 10, FontStyle.Bold), Color.Black);
            chart.Titles.Add(chartTitle);

            Legend legend = new Legend();
            legend.Docking = Docking.Bottom;
            legend.Alignment = StringAlignment.Center;
            chart.Legends.Add(legend);

            return chart;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            AnalyzeStability();
        }

        private void AnalyzeStability()
        {
            double a = 1.0, b = 0.5, c = 0.2, k = 2.0;
            double tau_critical = FindCriticalTau(a, b, c, k);

            PlotGeneralDynamics(a, b, c, k, tau_critical);
            PlotTauInfluence(a, b, c, k);
            PlotBInfluence(a, b, c, k);
            PlotAInfluence(a, b, c, k);
            PlotCInfluence(a, b, c, k);
            PlotKInfluence(a, b, c, k);
        }

        private double SimulateSystem(double a, double b, double c, double k, double tau, double tStop = DEFAULT_T_STOP)
        {
            double dt = DEFAULT_DT;
            int steps = (int)(tStop / dt);

            int tauSteps = (int)(tau / dt);
            double[] x = new double[steps + tauSteps + 2];
            double[] u = new double[steps + tauSteps + 2];

            x[0] = 0; x[1] = 0;
            u[0] = 0; u[1] = 0;

            double maxAmplitude = 0;

            for (int n = 1; n < steps; n++)
            {
                int delayedIndex = Math.Max(0, n - tauSteps);
                double error = 1.0 - x[delayedIndex];
                u[n] = k * error;

                double denominator = a + b * dt / 2;
                double numerator = 2 * a * x[n] - (a - b * dt / 2) * x[n - 1] +
                                 dt * dt * (u[n] - c * x[n]);

                x[n + 1] = numerator / denominator;

                maxAmplitude = Math.Max(maxAmplitude, Math.Abs(x[n + 1]));
            }

            return maxAmplitude;
        }

        private double FindCriticalTau(double a, double b, double c, double k)
        {
            double tauMin = 0;
            double tauMax = 5.0;
            double tolerance = 0.01;

            while (tauMax - tauMin > tolerance)
            {
                double tauMid = (tauMin + tauMax) / 2;
                double amplitude = SimulateSystem(a, b, c, k, tauMid, 100);

                if (amplitude > 10.0) 
                    tauMax = tauMid;
                else
                    tauMin = tauMid;
            }

            return (tauMin + tauMax) / 2;
        }

        private void PlotGeneralDynamics(double a, double b, double c, double k, double tauCritical)
        {
            Chart chart = charts[0];
            chart.Series.Clear();
            chart.ChartAreas[0].AxisX.Title = "�����";
            chart.ChartAreas[0].AxisY.Title = "x(t)";

            double[] taus = { 0, tauCritical * 0.5, tauCritical * 0.9, tauCritical * 1.1 };
            string[] labels = { "tau = 0 (���������)", $"tau = {tauCritical * 0.5:F2}",
                              $"tau = {tauCritical * 0.9:F2}", $"tau = {tauCritical * 1.1:F2} (�����������)" };

            Color[] colors = { Color.Blue, Color.Green, Color.Orange, Color.Red };

            for (int i = 0; i < taus.Length; i++)
            {
                var series = new Series(labels[i]);
                series.ChartType = SeriesChartType.Line;
                series.BorderWidth = 3;
                series.Color = colors[i];

                double dt = DEFAULT_DT;
                int steps = (int)(DEFAULT_T_STOP / dt);
                int tauSteps = (int)(taus[i] / dt);

                double[] x = new double[steps + tauSteps + 2];
                double[] u = new double[steps + tauSteps + 2];

                x[0] = 0; x[1] = 0;
                u[0] = 0; u[1] = 0;

                for (int n = 1; n < steps; n++)
                {
                    int delayedIndex = Math.Max(0, n - tauSteps);
                    double error = 1.0 - x[delayedIndex];
                    u[n] = k * error;

                    double denominator = a + b * dt / 2;
                    double numerator = 2 * a * x[n] - (a - b * dt / 2) * x[n - 1] +
                                     dt * dt * (u[n] - c * x[n]);

                    x[n + 1] = numerator / denominator;

                    if (n % 5 == 0)
                    {
                        series.Points.AddXY(n * dt, x[n + 1]);
                    }
                }

                chart.Series.Add(series);
            }
        }

        private void PlotTauInfluence(double a, double b, double c, double k)
        {
            Chart chart = charts[1];
            chart.Series.Clear();
            chart.ChartAreas[0].AxisX.Title = "tau";
            chart.ChartAreas[0].AxisY.Title = "������������ ���������";

            var series = new Series("���������");
            series.ChartType = SeriesChartType.Line;
            series.BorderWidth = 3;
            series.Color = Color.Blue;

            for (double tau = 0; tau <= 3.0; tau += 0.1)
            {
                double amplitude = SimulateSystem(a, b, c, k, tau, 100);
                series.Points.AddXY(tau, amplitude);
            }

            chart.Series.Add(series);
        }

        private void PlotBInfluence(double a, double b, double c, double k)
        {
            Chart chart = charts[2];
            chart.Series.Clear();
            chart.ChartAreas[0].AxisX.Title = "b";
            chart.ChartAreas[0].AxisY.Title = "����������� tau";

            var series = new Series("����������� tau");
            series.ChartType = SeriesChartType.Line;
            series.BorderWidth = 3;
            series.Color = Color.Green;

            for (double bVal = 0.1; bVal <= 2.0; bVal += 0.1)
            {
                double tauCritical = FindCriticalTau(a, bVal, c, k);
                series.Points.AddXY(bVal, tauCritical);
            }

            chart.Series.Add(series);
        }

        private void PlotAInfluence(double a, double b, double c, double k)
        {
            Chart chart = charts[3];
            chart.Series.Clear();
            chart.ChartAreas[0].AxisX.Title = "a";
            chart.ChartAreas[0].AxisY.Title = "����������� tau";

            var series = new Series("����������� tau");
            series.ChartType = SeriesChartType.Line;
            series.BorderWidth = 3;
            series.Color = Color.Red;

            for (double aVal = 0.5; aVal <= 3.0; aVal += 0.1)
            {
                double tauCritical = FindCriticalTau(aVal, b, c, k);
                series.Points.AddXY(aVal, tauCritical);
            }

            chart.Series.Add(series);
        }

        private void PlotCInfluence(double a, double b, double c, double k)
        {
            Chart chart = charts[4];
            chart.Series.Clear();
            chart.ChartAreas[0].AxisX.Title = "c";
            chart.ChartAreas[0].AxisY.Title = "����������� tau";

            var series = new Series("����������� tau");
            series.ChartType = SeriesChartType.Line;
            series.BorderWidth = 3;
            series.Color = Color.Purple;

            for (double cVal = 0.1; cVal <= 1.0; cVal += 0.05)
            {
                double tauCritical = FindCriticalTau(a, b, cVal, k);
                series.Points.AddXY(cVal, tauCritical);
            }

            chart.Series.Add(series);
        }

        private void PlotKInfluence(double a, double b, double c, double k)
        {
            Chart chart = charts[5];
            chart.Series.Clear();
            chart.ChartAreas[0].AxisX.Title = "k";
            chart.ChartAreas[0].AxisY.Title = "����������� tau";

            var series = new Series("����������� tau");
            series.ChartType = SeriesChartType.Line;
            series.BorderWidth = 3;
            series.Color = Color.Orange;

            for (double kVal = 0.5; kVal <= 5.0; kVal += 0.2)
            {
                double tauCritical = FindCriticalTau(a, b, c, kVal);
                series.Points.AddXY(kVal, tauCritical);
            }

            chart.Series.Add(series);
        }
    }

    class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}